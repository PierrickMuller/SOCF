Project for the Terasic DE1-Soc board

Look into the different folders for more details.

folder structure:
    - axi4lite: project that runs on the DE1-SoC board
    - IP_axi4lite_interface: IP source files
